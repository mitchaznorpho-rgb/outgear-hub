'use client';
import dynamic from 'next/dynamic';
import { useEffect } from 'react';
import mapboxgl from 'mapbox-gl';
mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN || '';

export default function MapPage(){
  useEffect(()=>{
    const map = new mapboxgl.Map({
      container: 'map',
      style: 'mapbox://styles/mapbox/streets-v12',
      center: [-111.8, 33.35],
      zoom: 10
    });
    fetch('/api/storage/listings').then(r=>r.json()).then(data=>{
      data.forEach((s:any)=>{
        const el = document.createElement('div');
        el.style.width = '10px'; el.style.height = '10px'; el.style.borderRadius = '50%'; el.style.background = '#7bd3ff';
        new mapboxgl.Marker(el).setLngLat([s.host.lon, s.host.lat]).setPopup(new mapboxgl.Popup().setHTML(`<b>${s.title}</b><br/>${s.priceMonthly}/mo`)).addTo(map);
      });
    });
    return ()=>map.remove();
  },[]);

  return <div style={{height:'calc(100vh - 80px)', padding:8}}><div id="map" style={{height:'100%', border:'1px solid #222a3a', borderRadius:12}}/></div>;
}
