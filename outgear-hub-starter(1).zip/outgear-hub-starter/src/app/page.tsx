import Link from 'next/link';
export default async function HomePage(){
  return (
    <main style={{padding:'1rem'}}>
      <h1 style={{fontSize:24,fontWeight:800}}>OutGear Hub</h1>
      <p>Store it. Rent it. All in one hub.</p>
      <div style={{display:'flex', gap:12, marginTop:12}}>
        <Link href="/map">Map</Link>
        <Link href="/storage">Storage</Link>
        <Link href="/rentals">Rentals</Link>
        <Link href="/owner">Owner</Link>
      </div>
    </main>
  );
}
