import { NextResponse } from 'next/server';
export async function GET(_: Request, { params }: { params: { id: string }}){
  const code = Math.random().toString(36).slice(2,8).toUpperCase();
  const pin = Math.floor(100000 + Math.random()*900000).toString();
  return NextResponse.json({ id: params.id, code, pin, status: 'preview' });
}
