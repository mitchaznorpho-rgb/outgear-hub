import { NextResponse } from 'next/server';
export async function POST(req: Request){
  const body = await req.json();
  // TODO: persist with Prisma
  return NextResponse.json({ ok:true, body });
}
