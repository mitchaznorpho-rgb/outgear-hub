import { NextResponse } from 'next/server';
export async function GET(){
  const data = [
    { id:'v1', title:'2019 Keystone Bullet 243BHS', kind:'RV Trailer', nightly:109 },
  ];
  return NextResponse.json(data);
}
