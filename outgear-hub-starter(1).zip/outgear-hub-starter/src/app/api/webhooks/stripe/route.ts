import { NextResponse } from 'next/server';
export async function POST(req: Request){
  // TODO: verify with STRIPE_WEBHOOK_SECRET
  const event = await req.text();
  console.log('Stripe webhook received (demo):', event.slice(0,200));
  return NextResponse.json({ received:true });
}
