'use client';
import { useEffect, useState } from 'react';

export default function OwnerPage(){
  const [vehicles, setVehicles] = useState<any[]>([]);
  useEffect(()=>{ fetch('/api/rentals/vehicles').then(r=>r.json()).then(setVehicles); },[]);
  async function save(v:any){
    await fetch('/api/owner/vehicle', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(v)});
    alert('Saved (demo)');
  }
  return (
    <main style={{padding:'1rem'}}>
      <h2 style={{fontSize:20,fontWeight:700}}>Owner Console</h2>
      {vehicles.map(v=>(
        <div key={v.id} style={{border:'1px solid #222a3a', padding:12, borderRadius:10, marginTop:8}}>
          <div><b>{v.title}</b> — {v.kind}</div>
          <label>Nightly:</label><input defaultValue={v.nightly} onBlur={e=>v.nightly=Number(e.target.value)} />
          <button onClick={()=>save(v)} style={{marginLeft:8}}>Save</button>
        </div>
      ))}
    </main>
  );
}
