export default async function StoragePage(){
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ''}/api/storage/listings`, { cache: 'no-store' });
  const items = await res.json();
  return (
    <main style={{padding:'1rem'}}>
      <h2 style={{fontSize:20,fontWeight:700}}>Storage listings</h2>
      <ul>{items.map((s:any)=>(<li key={s.id}><b>{s.title}</b> — {s.host.city}, {s.host.state} — ${'{'}s.priceMonthly{'}'}/mo</li>))}</ul>
    </main>
  );
}
