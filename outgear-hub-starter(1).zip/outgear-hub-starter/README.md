# OutGear Hub — Full‑Stack Starter (Next.js 14 + Postgres + Prisma)

This is a minimal, *runnable* starter for the OutGear Hub MVP.

## What you get
- Next.js 14 (App Router, TypeScript, Route Handlers)
- Postgres + Prisma (with PostGIS-ready notes)
- Stripe stubs (Subscriptions for storage, payments for rentals, Connect for payouts)
- Mapbox GL map page + basic API endpoints (storage listings, vehicles, release pass)
- Owner blackout dates and vehicle editing endpoints (skeleton)
- Docker Compose for Postgres
- Auth ready for integration (Clerk/NextAuth placeholder)

## Quick start
```bash
# 1) Start Postgres
docker compose up -d

# 2) Install deps
npm install

# 3) Set env vars
cp .env.example .env
# fill in: DATABASE_URL, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, MAPBOX_TOKEN

# 4) Initialize DB
npx prisma migrate dev --name init

# 5) Seed (optional)
npm run seed

# 6) Run dev server
npm run dev
```

## Scripts
- `npm run dev` – Next dev server
- `npm run prisma:studio` – open Prisma Studio
- `npm run seed` – seeds demo hosts, spaces, vehicles

## Notes
- Release Pass is issued at rental confirmation and stored in `release_passes` with QR/PIN.
- For production: add PostGIS, S3 uploads, auth provider (Clerk/NextAuth), and Stripe Connect onboarding.
